**To deactivate a user**

This example deactivates an active user.

Command::

  aws workdocs deactivate-user --user-id "S-1-1-11-1111111111-2222222222-3333333333-3333&d-926726012c"

Output::

  None