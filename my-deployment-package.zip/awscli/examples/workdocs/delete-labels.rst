**To delete labels**

This example deletes the specified labels from a document.

Command::

  aws workdocs delete-labels --resource-id d90d93c1fe44bad0c8471e973ebaab339090401a95e777cffa58e977d2983b65 --labels "documents" "examples"

Output::

  None