**To detach a policy from a root, OU, or account**

The following example shows how to detach a policy from an OU: ::

	aws organizations  detach-policy  --target-id ou-examplerootid111-exampleouid111 --policy-id p-examplepolicyid111
