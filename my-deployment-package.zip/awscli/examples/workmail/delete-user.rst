**To delete a user**

The following ``delete-user`` command deletes the specified user from Amazon WorkMail and all subsequent systems. ::

    aws workmail delete-user \
        --organization-id m-d281d0a2fd824be5b6cd3d3ce909fd27 \
        --user-id S-1-1-11-1111111111-2222222222-3333333333-3333

This command produces no output.
